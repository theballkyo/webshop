<?php
class ProductsStock extends Eloquent {

	protected $table = "products_stock";

}