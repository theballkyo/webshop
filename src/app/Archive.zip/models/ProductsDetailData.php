<?php
class ProductsDetailData extends Eloquent {

	protected $table = "products_detail_data";

	public function Color()
    {
    	return $this->hasOne('Color', 'id');
    }
}