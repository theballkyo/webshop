<?php
class Color extends Eloquent {

	protected $table = "color_code";

}