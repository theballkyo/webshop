@extends('layouts.admin')
@section('content')
<div class="row">
     @include('layouts.admin-nav')
     <div class="span9">
        <div class="content">
            <div class="module">
                <div class="module-head">
                <h3>
                Welcome ,{{ Auth::user()->username }}</h3>
                </div>
                <div class="module-body">
                    <p>
                    <strong>Default</strong>
                    -
                    <small>table class="table"</small>
                    </p>
                    <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>First Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>Mark</td>

                        </tr>
                        <tr>
                            <td>1</td>
                            <td>Mark</td>

                        </tr>
                        <tr>
                            <td>1</td>
                            <td>Mark</td>

                        </tr>
                        <tr>
                            <td>1</td>
                            <td>Mark</td>

                        </tr>
                    </tbody>
                    </table>
            </div>
        </div>
    </div>
    <!--/.span9-->
</div>
@stop