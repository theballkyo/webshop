<div class="span3">
                        <div class="sidebar">
                            <ul class="widget widget-menu unstyled">
                                <li class="active"><a href="{{ url('/admin') }}"><i class="menu-icon icon-dashboard"></i>Dashboard
                                </a></li>
                                <li><a href="{{url('/admin/products')}}"><i class="menu-icon icon-bullhorn"></i>Products</a>
                                </li>
                                <li><a href="{{url('/admin/stocks')}}"><i class="menu-icon icon-inbox"></i>Stocks<b class="label green pull-right">
                                    11</b> </a></li>
                                <li><a href="{{url('/user/logout')}}"><i class="menu-icon icon-tasks"></i>Logout<b class="label orange pull-right">
                                    19</b> </a></li>
                            </ul>
                            <!--/.widget-nav-->
                        </div>
                        <!--/.sidebar-->
                    </div>
                    <!--/.span3-->